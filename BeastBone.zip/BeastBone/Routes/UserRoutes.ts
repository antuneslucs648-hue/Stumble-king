import { Router } from 'express';
import { 
  userGet, 
  userChangeNick,
  userReport,
  userSync
} from '../Controllers/UserController';
import { validateAppId, authenticateToken } from '../Middleware/Index';

const router = Router();

router.post('/userGet', validateAppId, authenticateToken, userGet);
router.post('/userChangeNick', validateAppId, authenticateToken, userChangeNick);
router.post('/userReport', validateAppId, authenticateToken, userReport);
router.post('/userSync', validateAppId, authenticateToken, userSync);



export default router;

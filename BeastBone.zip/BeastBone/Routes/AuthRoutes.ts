import { Router } from 'express';
import {
  ping,
  userLogin,
  userConnect,
  refreshAccessToken
} from '../Controllers/AuthController';
import { validateAppId, authenticateToken } from '../Middleware/Index';

const router = Router();

router.get('/ping', ping);

router.post('/userLogin', validateAppId, userLogin);
router.post('/userConnect', validateAppId, authenticateToken, userConnect);
router.post('/refreshAccessToken', validateAppId, refreshAccessToken);

export default router;

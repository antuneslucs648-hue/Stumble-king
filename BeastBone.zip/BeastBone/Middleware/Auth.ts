import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { findByAcessToken } from '../Config/Database';
import { serverConfig } from '../Config/Server';
import { createResponse } from '../Utils/Response';

const getAccessToken = (req: Request): string | null => {
  const authorization = req.header('authorization');
  if (authorization?.toLowerCase().startsWith('bearer ')) {
    return authorization.slice(7).trim();
  }
  return req.header('access_token')
    || req.header('backbone_access_token')
    || (typeof req.body?.accessToken === 'string' ? req.body.accessToken : null);
};

export const authenticateToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  const accessToken = getAccessToken(req);
  if (!accessToken) {
    res.status(401).json(createResponse(401, 'Access token required', null, 'AUTH_001'));
    return;
  }

  try {
    jwt.verify(accessToken, serverConfig.jwtSecret);
    const user = await findByAcessToken(accessToken) as any;
    if (!user) {
      res.status(401).json(createResponse(401, 'Invalid access token', null, 'AUTH_002'));
      return;
    }
    if (user.expireAt && new Date(user.expireAt).getTime() <= Date.now()) {
      res.status(401).json(createResponse(401, 'Access token expired', null, 'AUTH_003'));
      return;
    }
    (req as any).user = user;
    next();
  } catch {
    res.status(401).json(createResponse(401, 'Invalid access token', null, 'AUTH_002'));
  }
};

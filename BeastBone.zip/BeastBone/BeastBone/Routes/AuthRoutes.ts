import { Router } from 'express';
import { ping, userLogin } from '../Controllers/AuthController';

const router = Router();

// Public health check.
router.get('/ping', ping);

// Expose the login controller. The app mounts this router at /api/v1,
// so these endpoints become /api/v1/login and /api/v1/userLogin.
router.post('/login', userLogin);
router.post('/userLogin', userLogin);

export default router;

# Backend corrigido — StumbleBeast 0.64

Correções aplicadas:

- Rotas `POST /api/v1/userLogin`, `POST /api/v1/userConnect` e `POST /api/v1/refreshAccessToken` adicionadas.
- Validação real do JWT e busca do usuário no MongoDB adicionadas ao middleware.
- Rota `POST /api/v1/userSync` adicionada.
- Tokens expirados são renovados durante um novo login.
- Tratamento de erros HTTP corrigido para não transformar falhas em resposta `200`.
- Rotina periódica de torneios recebeu tratamento de rejeições.
- Compatibilidade de compilação do TypeScript ajustada.
- Incluído `.env.example`.

## Configuração

1. Copie `.env.example` para `.env`.
2. Defina `mongouri`, `secret` e o valor correto de `appIds`.
3. Instale dependências com `npm ci`.
4. Compile com `npm run build`.
5. Inicie com `npm start`.

O APK ainda precisa apontar para a URL pública deste backend. A análise estática encontrou a URL original do Backbone dentro do APK; o backend corrigido não altera o endereço embutido no APK.
